$Id

Usage instructions:

1. Install the module and configure permissions to allow import.
2. Prepare a site map file (use sitemap_sample.txt as example to understand syntax and features)
3. Go to Site building -> Menus
4. Select "Menu import" tab
5. Select the site map file created earlier and specify necessary options
6. Submit and see the new menu structure with stub nodes created automatically.
7. Enjoy your saved time ;)

Features:
TO BE DOCUMENTED...

